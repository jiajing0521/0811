<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>旋风赛车</title>
    <style>
        *{
            margin:0;
            padding:0;
        }
        html,body,#allGame{
            width: 100%;
            height:100%;
        }
        .timerClock{
            width:36%;
            height:12%;
            position: absolute;
            left: 2%;
            top:1%;

            text-align: right;
            background: url("img/timerClock.png") no-repeat;
            background-size: 100% 100%;
            z-index: 99;
        }
        .timerClockP{
            width: 100%;
            height:30%;
            color: white;
            font-size: 1em;
            position: absolute;
            top:52%;
            left:-12%;
        }
        .starting_line{
            width:83.333333%;
            height:8%;
            position: absolute;
            left: 9.16666%;
            top:52.52173%;
            z-index: 99;
        }
        .light{
            width:20%;
            height:28.17391%;
            position: absolute;
            left: 40.277777%;
            top:11.47826%;
            z-index: 99;
        }
        .ready{
            width:33.88888%;
            height:4.86956%;
            position: absolute;
            left: 33.61111%;
            top:42.43478%;
            z-index: 99;
        }

    </style>
</head>
<body>
<div id="allGame">
    <canvas id="canvas" width="" height="">
        低版本浏览器不支持
    </canvas>

    <!--计时器-->
    <div class="timerClock">
        <p class="timerClockP">
        <span class="score1">0</span>:<span class="score2">0</span>:<span class="score3">30</span>
        </p>
    </div>
    <!--起跑线-->
    <img src="img/starting_line.png" alt="" class="starting_line">
    <img src="" alt="" class="light">
    <img src="img/READY.png" alt="" class="ready">

    <img src="img/timerClock.png" alt="" >

</div>
<!--游戏开始-->
<script src="js/loading.js" type="text/javascript"></script>
<script src="js/jquery-2.2.3.min.js" type="text/javascript"></script>
<script type="text/javascript">
    var canvas = document.getElementById("canvas");
    var ctx = canvas.getContext("2d");

    canvas.width = document.documentElement.clientWidth;
    canvas.height = document.documentElement.clientHeight;

    //调用，传入图片对象参数，图片处理函数
    loading({"racing":"img/racing.png","speedBtn0":"img/speedBtn0.png","speedBtn1":"img/speedBtn1.png","speedBtn2":"img/speedBtn2.png",
        "btn_right":"img/btn_right.png","btn_left":"img/btn_left.png","car0":"img/car0.png","car1":"img/car1.png",
        "light0":"img/light0.png","light1":"img/light1.png","light2":"img/light2.png","timerClock":"img/timerClock.png",
        "startingline":"img/starting_line.png","roadblock":"img/roadblock.png","roadcar0":"img/roadcar0.png","roadcar1":"img/roadcar1.png",
        "roadcar2":"img/roadcar2.png"},
        function(a) {
            //图片加载的进度
//            console.log(a);
        },main
    );

    function main(imgobj) {

        /************主角车*************/
        var car = {
            img: imgobj.car0,
            w: canvas.width*0.1416666,
            h: canvas.height*0.1721739,
            x: canvas.width*0.430555,
            y: canvas.height*0.607

        };
        car.draw = function () {
            if (addSpeed){
                this.img = imgobj.car1;
                this.h = canvas.height*0.2130434;
            }else {
                this.img = imgobj.car0;
                this.h = canvas.height*0.1721739;
            }
            ctx.drawImage(this.img,this.x,this.y,this.w,this.h);
        };

        /************加速器*************/
        var speedBtn = {
            img: imgobj.speedBtn1,
            w: canvas.width*0.16111111,
            h: canvas.height*0.1791304,
            x: canvas.width*0.8138888,
            y: canvas.height*0.7495652

        };
        speedBtn.draw = function () {
            if (addSpeed){
                this.img = imgobj.speedBtn2;
                this.h = canvas.height*0.147826;
            }else {
                this.img = imgobj.speedBtn1;
                this.h = canvas.height*0.1791304;
            }
            ctx.drawImage(this.img,this.x,this.y,this.w,this.h);
        };

        /************障碍物*************/
        function Roadblock () {
            this.img = imgobj.roadblock;
            this.w = canvas.width*0.0847222;
            this.h = canvas.height*0.0626087;
            this.x = rand(canvas.width*0.0944444,canvas.width-this.w-canvas.width*0.0944444*2);
            this.y = -this.h;
            if (addSpeed){
                if (changeSpeed <= maxSpeed){
                    changeSpeed += 0.05;
                }
                this.speed = changeSpeed;
            }else{
                if (changeSpeed >= minSpeed){
                    changeSpeed -= 0.05;
                }
                this.speed = changeSpeed;
            }
            this.score = 1;
        };
        Roadblock.prototype.draw = function(){
        	ctx.drawImage(this.img,this.x,this.y,this.w,this.h);
        };
        Roadblock.prototype.move = function () {
            this.y += this.speed;
        };
        Roadblock.prototype.canClear = function () {
            return this.y >= canvas.height;
        };
        var roadblocks = [];
        

        /************障碍车*************/
        function Roadcar () {
        	
            this.img = imgobj.roadcar0;
            this.w = canvas.width*0.1333333;
            this.h = canvas.height*0.1860869;
            this.x = rand(canvas.width*0.0944444,canvas.width-this.w-canvas.width*0.0944444);
            this.y = -this.h;
            if (addSpeed){
                if (changeSpeed <= maxSpeed){
                    changeSpeed += 0.05;
                }
                this.speed = changeSpeed;
            }else{
                if (changeSpeed >= minSpeed){
                    changeSpeed -= 0.05;
                }
                this.speed = changeSpeed;
            }
            this.score = 3;
        };
        Roadcar.prototype.position = function(){
            while (true) {
                var x = rand(canvas.width * 0.0944444, canvas.width - this.w - canvas.width * 0.0944444*2);
                for (var i = 0; i < roadblocks.length; i++) {
                    var position = roadblocks[i];
                    if (this.x >= position.x && this.x<= position.x + position.w && this.y >= position.y && this.y >= position.y + position.h) {
                        break;
                    }
                }
                if (i == roadblocks.length) {
                    //说明没有冲突,随机的位置保留，结束while循环
                    this.x = x;
                    break;
                }
            }
        };
        Roadcar.prototype.draw = function(){
        	ctx.drawImage(this.img,this.x,this.y,this.w,this.h);
        };
        Roadcar.prototype.move = function () {
            this.y += this.speed;
        };
        Roadcar.prototype.canClear = function () {
            return this.y >= canvas.height;
        };
        var roadcars = [];
        
        function rand(min,max) {
            return Math.floor(Math.random()*(max + 1 -min) + min);
        }

        //碰撞检测
        function checkP(obj1, obj2) {
            //x轴方向最小距离
            var disX = obj1.w/2 + obj2.w/2;
            //y轴
            var disY = obj1.h/2 + obj2.h/2;

            //两个矩形x轴方向实际的中心距
            var realX = Math.abs((obj1.x + obj1.w/2) - (obj2.x + obj2.w/2));
            //y轴
            var realY = Math.abs((obj1.y + obj1.h/2) - (obj2.y + obj2.h/2));

            if (realX <= disX && realY <= disY) {
                return true;
            }else {
                return false;
            }
        }

        /************画布运动*************/

        //背景向下偏移量Y

        var moveY = 0;
        var lightCount = 0;
        var timerClocks = 30;
        var time = 0;
        var addSpeed = false;
        var speedCount = 0;
        var changeSpeed = 3;
        var maxSpeed = 6;
        var minSpeed = 3;
        var gameOver = false;
        var gameScores = 0;

        //倒计时红绿灯
        function timerLight() {
            if (lightCount < 3){
                setTimeout(timerLight,1000);
                $(".light").attr("src","img/light"+lightCount+".png");
                lightCount++;
            }else {
                $(".light").css({display:"none"});
                $(".starting_line").css({display:"none"});
                $(".ready").css({display:"none"});
                timerClock();
            }
        }
        timerLight();

        //计时器
        function timerClock() {
            $(".score3").html(timerClocks);
            if (timerClocks > 0 && gameOver == false){
                setTimeout(timerClock,1000);
            }else {
                gameOver = true;
            }
            timerClocks--;
        }

        function run() {
            //清空画布
            ctx.clearRect(0,0,canvas.width,canvas.height);

            //1.背景图运动
            time++;
            if (time >= 270){
                if (addSpeed){
                    if (changeSpeed <= maxSpeed){
                        changeSpeed += 0.05;
                    }
                    moveY += changeSpeed;
                }else{
                    if (changeSpeed >= minSpeed){
                        changeSpeed -= 0.05;
                    }
                    moveY += changeSpeed;
                }
                if (moveY >= canvas.height){
                    moveY=0;
                }
                ctx.drawImage(imgobj.racing,0,-canvas.height+moveY,canvas.width,canvas.height);
                ctx.drawImage(imgobj.racing,0,moveY,canvas.width,canvas.height);
            }else{
                ctx.drawImage(imgobj.racing,0,0,canvas.width,canvas.height);
            }
            //终点线
            if (gameOver){
                ctx.drawImage(imgobj.startingline,canvas.width*0.0916666,canvas.height*0.5252173,canvas.width*0.83333333,canvas.height*0.08);
//                roadblocks = [];
//                roadcars = [];
            }

            //2.主角车
            car.draw();
            //3.障碍物
            if (time >= 300 && time <= 2700) {
            	if (time%93 == 0) {
	            	var roadblock = new Roadblock();
	            	roadblocks.push(roadblock);
	            }
            }
            
            for (var i = 0; i < roadblocks.length; i++) {
            	var roadblock = roadblocks[i];
            	roadblock.draw();
            	roadblock.move();
            	if (roadblock.canClear()){
                    roadblocks.splice(i,1);
                    i--;
//                    gameScores += roadblock.score;
                }
            }
            
            //4.障碍车
            if (time >= 300 && time <= 2700) {
            	if (time%153 == 0) {
	            	var roadcar = new Roadcar();
                    roadcar.position();
	            	roadcars.push(roadcar);
	            }
            }
            for (var i = 0; i < roadcars.length; i++) {
            	var roadcar = roadcars[i];
            	roadcar.move();
            	if(time%463 == 0){
            		roadcar.img = imgobj.roadcar2;
            		roadcar.w = canvas.width*0.175;
            		roadcar.h = canvas.height*0.1860869;
            	}
            	
            	roadcar.draw();
            	if (roadcar.canClear()){
                    roadcars.splice(i,1);
                    i--;
//                    gameScores += roadcar.score;
                }
            }
            //5.加速器
            speedBtn.draw();
            
            //6.左右控制按钮
            ctx.drawImage(imgobj.btn_left,canvas.width*0.2152777,canvas.height*0.777391,canvas.width*0.2152777,canvas.height*0.1347826);
            ctx.drawImage(imgobj.btn_right,canvas.width*0.5722222,canvas.height*0.777391,canvas.width*0.2152777,canvas.height*0.1347826);

            //6.碰撞检测

            for (var i = 0; i < roadcars.length; i++){
                if (checkP(roadcars[i],car)){
                    gameOver = true;
                }else
                if (roadcars[i].y >= car.y + car.h && roadcars[i].y <= car.y + car.h + 5 ){
                    gameScores += roadcars[i].score;
                }
            }

            for (var i = 0; i < roadblocks.length; i++){
                if (checkP(roadblocks[i],car)){
                    gameOver = true;
                }else
                if (roadblocks[i].y >= car.y + car.h && roadblocks[i].y <= car.y + car.h + 5){
                    gameScores += roadblocks[i].score;
                }
            }


			if (gameOver == false){
                setTimeout(run,10);
                console.log(gameScores);
			}
        }
        run();

        function reRun() {
            moveY = 0;
            lightCount = 0;
            timerClocks = 30;
            time = 0;
            addSpeed = false;
            speedCount = 0;
            gameOver = false;
            gameScores = 0;
            roadcars = [];
            roadblocks = [];

            ctx.clearRect(0,0,canvas.width,canvas.height);
            ctx.drawImage(imgobj.racing,0,0,canvas.width,canvas.height);
            car.x = canvas.width*0.430555;
            car.y = canvas.height*0.607;
            car.draw();
            speedBtn.draw();
            ctx.drawImage(imgobj.btn_left,canvas.width*0.2152777,canvas.height*0.777391,canvas.width*0.2152777,canvas.height*0.1347826);
            ctx.drawImage(imgobj.btn_right,canvas.width*0.5722222,canvas.height*0.777391,canvas.width*0.2152777,canvas.height*0.1347826);

            $(".score3").html(timerClocks);
            $(".light").css({display:"block"});
            $(".starting_line").css({display:"block"});
            $(".ready").css({display:"block"});

            timerLight();
            run();
        }
        $(".timerClock").on("click",function () {
            reRun();
        });

        
        //点击左右控制按钮
        var leftTimer,rightTimer;
        document.addEventListener("touchstart",function (e) {
            var e = e.touches[0];
            var X = e.clientX;
            var Y = e.clientY;
            //判断是否点击到
            if ((X >= canvas.width*0.2152777 && X <= (canvas.width*0.2152777+canvas.width*0.2152777)) && (Y >= canvas.height*0.777391 && Y <= (canvas.height*0.777391+canvas.height*0.1347826))){
                clearInterval(leftTimer);
                leftTimer = setInterval(function () {
                    //判断屏幕边界
                    if (car.x <=canvas.width*0.085 ){
                        clearInterval(rightTimer);
                        clearInterval(leftTimer);
                        car.x = canvas.width*0.085;
                    }else{
                        car.x = car.x - 1;
                    }
                },1);
            }else if ((X >= canvas.width*0.5722222 && X <= (canvas.width*0.5722222+canvas.width*0.2152777)) && (Y >= canvas.height*0.777391 && Y <= (canvas.height*0.777391+canvas.height*0.1347826))){
                clearInterval(rightTimer);
                rightTimer = setInterval(function () {
                    //判断屏幕边界
                    if (car.x >= canvas.width - car.w - canvas.width*0.085 ){
                        clearInterval(rightTimer);
                        clearInterval(leftTimer);
                        car.x = canvas.width - car.w - canvas.width*0.085 ;
                    }else{
                        car.x = car.x + 1;
                    }

                },1);
            }
        });
        document.addEventListener("touchend",function (e) {
                var t = e.changedTouches[0];
                clearInterval(rightTimer);
                clearInterval(leftTimer);
        });

        //点击加速控制按钮
        document.addEventListener("touchstart",function (e) {
            var e = e.touches[0];
            var X = e.clientX;
            var Y = e.clientY;
            //判断是否点击到
            if ((X >= canvas.width*0.8138888 && X <= (canvas.width*0.8138888+canvas.width*0.175)) && (Y >= canvas.height*0.7495652 && Y <= (canvas.height*0.7495652+canvas.height*0.1617391))){
                if (speedCount%2 == 0){
                    addSpeed = true;
                }else {
                    addSpeed = false;
                }
                speedCount++;
            }
        });
    }

    //阻止手机的touchmove默认事件，防止页面可以拖动
    document.addEventListener("touchmove",function (e) {
        var e = e || window.event;
        e.preventDefault();
    },false);



</script>
</body>
</html>